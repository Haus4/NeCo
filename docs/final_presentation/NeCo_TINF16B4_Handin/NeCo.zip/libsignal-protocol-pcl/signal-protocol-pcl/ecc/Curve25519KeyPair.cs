﻿namespace libaxolotl_csharp.ecc
{
	public class Curve25519KeyPair
	{
		public byte[] PublicKey;
		public byte[] PrivateKey;
	}
}