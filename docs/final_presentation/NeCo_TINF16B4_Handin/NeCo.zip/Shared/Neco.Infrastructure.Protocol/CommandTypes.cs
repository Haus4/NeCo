﻿namespace Neco.Infrastructure.Protocol
{
    public enum CommandTypes
    {
        Unknown = -1,
        Ping = 0,
        Response,
        Request,
    }
}
