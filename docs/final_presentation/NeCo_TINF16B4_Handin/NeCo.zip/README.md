# NeCo
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/6a61f6a242244a8896d7ab31b544bf6f)](https://www.codacy.com/app/momo5502/NeCo?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Haus4/NeCo&amp;utm_campaign=Badge_Grade)  
Near Comm App
[SRS]

Our App is released on the Google Play Store, you can get it here:

<a href='https://play.google.com/store/apps/details?id=de.dhbw.neco.client&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/></a>



[SRS]: https://github.com/Haus4/NeCo/blob/master/docs/SRS.md "Link to Software Requirement Spec"
