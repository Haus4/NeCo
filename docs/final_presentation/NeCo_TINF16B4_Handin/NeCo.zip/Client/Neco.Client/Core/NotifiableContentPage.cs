﻿using Xamarin.Forms;

namespace Neco.Client
{
    public class NotifiableContentPage : ContentPage
    {
        public NotifiableContentPage() : base()
        {

        }

        public virtual void OnPopped()
        {

        }
    }
}
