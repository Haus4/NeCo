﻿namespace Neco.Client
{
    public interface IMessage
    {
        void ShowToast(string message);
    }
}
